



<?php $__env->startSection('content'); ?>

<!-- ======================= Border Start Topbar ================== -->

<section class="mt-4">

    <div class="container">

    <div class="row">

        <div class="offset-lg-9 col-lg-3 col-sm-12">

            <a href="<?php echo e(route('add_category')); ?>" class="primary-btn"><i class="bx bxs-plus-circle"></i> Add Category </a>

        </div>

    </div>



    </div>

</section>

<!-- ======================= Border End Topbar ================== -->



<div class="body">

    <div class="card">

        <div class="card-body">

            <?php if(\Session::has('errmsg')): ?>

                <div class="alert alert-danger">

                    <ul>

                        <li><?php echo \Session::get('errmsg'); ?></li>

                    </ul>

                </div>

            <?php endif; ?>

            <?php if(\Session::has('successmsg')): ?>

                <div class="alert alert-success">

                    <ul>

                        <li><?php echo \Session::get('successmsg'); ?></li>

                    </ul>

                </div>

            <?php endif; ?>

            <div class="align-items-center d-md-flex justify-content-between mb-4">

                <div class="">

                    <h1 class="card-title m-md-0 mb-3"> All Category</h1>

                </div>

            </div>

            

            <div id="all-orders" class="table-responsive-sm position-relative withdra-tab-content active">

                <table class="display responsive nowrap w-100 Queries">

                    

                    <thead>

                        <tr>

                            <th>Name</th>

                            <th>action</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td>

                                <span class="pr-title">

                                    <?php echo e($category->name); ?>


                                </span>

                            </td>

                            <td class="">

                                <div class="btn-group dropstart">

                                    <button type="button" class="action-btn" data-bs-toggle="dropdown" aria-expanded="false">

                                        <i class='bx bx-dots-vertical-rounded'></i>

                                    </button>

                                    <ul class="dropdown-menu svg-icon">

                                        <li> <a href="<?php echo e(route('edit_category', $category->id)); ?>">Edit  </a> </li>

                                        <li> <a onclick="return confirm('Are you sure to delete?')" href="<?php echo e(route('category_delete', $category->id)); ?>">Delete</a> </li>

                                    </ul>

                                </div>

                            </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>

<script>


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/admin/all-categories.blade.php ENDPATH**/ ?>