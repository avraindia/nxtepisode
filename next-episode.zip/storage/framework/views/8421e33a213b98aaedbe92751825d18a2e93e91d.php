<table class="display coustom-table nowrap w-100 Queries">
    <thead>
        <tr>
            <th><a href="javascript:void(0);" class="sort_item" item="categories.name">Name</a></th>
            <th>Status</th>
            <th>action</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $all_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="table-body-tr">
            <td>
                <span class="pr-title">
                    <?php echo e($category->name); ?>

                </span>
            </td>
            <td>
                <div class="order-place-tag them-color">
                <?php if($category->is_active =='1'): ?>
                    Published
                <?php else: ?>
                    Unpublished
                <?php endif; ?>
                </div>
            </td>
            <td class="">
                <div class="btn-group dropstart">
                    <button type="button" class="action-btn" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class='bx bx-dots-vertical-rounded'></i>
                    </button>
                    <ul class="dropdown-menu svg-icon">
                        <li> <a href="javascript:void(0);" class="edit_cat_btn" cat_id="<?php echo e($category->id); ?>">Edit  </a> </li>
                        <li> <a onclick="return confirm('Are you sure to delete?')" href="<?php echo e(route('category_delete', $category->id)); ?>">Delete</a> </li>
                    </ul>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination-section">
    <?php echo $all_categories->links(); ?>

</div><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/admin/categories-child.blade.php ENDPATH**/ ?>