<table class="display coustom-table nowrap w-100 Queries">
    <thead>
        <tr>
            <th><a href="javascript:void(0);" class="sort_item" item="users.name">Name</a></th>
            <th><a href="javascript:void(0);" class="sort_item" item="users.email">Email</a></th>
            <th><a href="javascript:void(0);" class="sort_item" item="users.email">Phone</a></th>
            <th><a href="javascript:void(0);" class="sort_item" item="users.email">Gender</a></th>
            <th><a href="javascript:void(0);" class="sort_item" item="users.created_at">Registration Date</a></th>
            <th class="text-center">action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="table-body-tr">
            <td>
                <span class="pr-title">
                    <?php echo e($user->name); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($user->email); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($user->phone_number); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php if($user->gender =='m'): ?>
                        Male
                    <?php else: ?>
                        Female
                    <?php endif; ?>
                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e(date('d.m.Y', strtotime($user->created_at))); ?>

                </span>
            </td>
            <td class="text-center">
                <div class="btn-group dropstart">
                    <button type="button" class="action-btn" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class='bx bx-dots-vertical-rounded'></i>
                    </button>
                    <ul class="dropdown-menu svg-icon">
                        <li> <a href="<?php echo e(route('customer_details',$user->id)); ?>">User Details</a> </li>
                    </ul>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination-section">
    <?php echo $users->links(); ?>

</div><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/admin/customers-child.blade.php ENDPATH**/ ?>