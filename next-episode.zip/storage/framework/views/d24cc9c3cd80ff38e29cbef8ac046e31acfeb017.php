<div class="product-filter-product-right-side-header-text">
    <h5>Showing results of - <span class="product-items-color-text"><?php echo e($product_count); ?>

            items</span></h5>
</div>
<div class="product-filter-product-image-price-section">
    <div class="row">
        <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-lg-4 col-lg-6 col-6">
            <div class="product-details-section">
                <a href="<?php echo e(route('front_product_details',base64_encode($product->id))); ?>">
                    <div class="product-filter-product-image">
                        <?php $__currentLoopData = $product->gallery_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $product_thumbnail_image_link = $image->product_thumbnail_image_link;
                            ?>
                            <?php break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($product_thumbnail_image_link); ?>" alt="">
                    </div>
                    <div class="product-filter-product-image-name-text">
                        <h5><?php echo e($product->fitting_title); ?></h5>
                    </div>
                    <div class="product-filter-product-image-details-text">
                        <h6><?php echo e($product->cat_name); ?></h6>
                    </div>
                    <div class="product-image-price-section">
                        <span class="offer-price">₹ <?php echo e($product->product_mrp); ?></span>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-lg-12">
        <nav>
        <?php echo $all_products->links(); ?>

        </nav>
    </div>
</div><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/frontend/products-child.blade.php ENDPATH**/ ?>