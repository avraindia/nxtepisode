<div class="navigation">
    <div class="logo-box">
        <a href="">
            <img src="<?php echo e(asset('backend/images/logo.png')); ?>" class="img-fluid" alt="" style="width:100px;">
        </a>
    </div>
    <?php
        $route_name = request()-> route()-> getname();
    ?>
    <ul>
        <li <?php if(in_array($route_name, ['dashboard'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('dashboard')); ?>">
                <span class="menu-icon">
                    <i class="fa fa-tachometer" aria-hidden="true"></i>
                </span>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li <?php if(in_array($route_name, ['users', 'add_user', 'user_details'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('users')); ?>">
                <span class="menu-icon">
                    <i class="fa fa-users" aria-hidden="true"></i>
                </span>
                <span class="menu-title">Admin Users</span>
            </a>
        </li>
        <li <?php if(in_array($route_name, ['customers', 'customer_details'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('customers')); ?>">
                <span class="menu-icon">
                    <i class="fa fa-users" aria-hidden="true"></i>
                </span>
                <span class="menu-title">Customers</span>
            </a>
        </li>
        <li <?php if(in_array($route_name, ['all_categories', 'add_category', 'edit_category', 'category_delete'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('all_categories')); ?>">
                <span class="menu-icon">
                    <img src="<?php echo e(asset('backend/images/icon/category.svg')); ?>" class="img-fluid " alt="">
                </span>
                <span class="menu-title">Category</span>
            </a>
        </li>
        <li <?php if(in_array($route_name, ['options', 'add_option_value'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('options')); ?>">
                <span class="menu-icon">
                    <img src="<?php echo e(asset('backend/images/icon/icon-option.png')); ?>" class="img-fluid " alt="">
                </span>
                <span class="menu-title">Options</span>
            </a>
        </li>
        <li <?php if(in_array($route_name, ['all_products', 'add_product', 'product_details'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('all_products')); ?>">
                <span class="menu-icon">
                    <img src="<?php echo e(asset('backend/images/icon/icon-shirt.png')); ?>" class="img-fluid " alt="">
                </span>
                <span class="menu-title">Products</span>
            </a>
        </li>
        <li <?php if(in_array($route_name, ['inventory_list', 'inventory'])): ?> ? class="hovered" : '' <?php endif; ?>>
            <a href="<?php echo e(route('inventory_list')); ?>">
                <span class="menu-icon">
                    <img src="<?php echo e(asset('backend/images/icon/icon-inventory.png')); ?>" class="img-fluid " alt="">
                </span>
                <span class="menu-title">Inventory</span>
            </a>
        </li>
    </ul>
</div><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/includes/admin/left-menu.blade.php ENDPATH**/ ?>