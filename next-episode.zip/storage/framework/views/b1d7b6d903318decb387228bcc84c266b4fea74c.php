<div class="col-lg-3 col-md-4 col-12">
    <div class="add-class-for-responsive" id="responsive-filter-option-section">
        <div class="product-select-search-section product-select-responsive">
            <select name="cars" id="products" class="order_by_mobile">
                <option selected disabled>Select Sorting Options</option>
                <option value="price_high_to_low">Price-High to Low</option>
                <option value="price_low_to_high">Price-Low to High</option>
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
            </select>
        </div>
        <div class="product-responsive-filter-btn">
            <button class="acc filter-button active-filter-btn" data-filter="categories">Categories</button>
            <button class="acc filter-button" data-filter="themes">THEMES</button>
            <button class="acc filter-button" data-filter="size">Size</button>
            <button class="acc filter-button" data-filter="gender">Gender</button>
            <button class="acc filter-button" data-filter="stock">Stock</button>
            <button class="acc filter-button" data-filter="prices">Prices</button>
        </div>
        <div class="product-left-right-section">
            <div class="product-section padding-section filter categories">
                <div class="filter-section-header-text">
                    <h5>Categories</h5>
                </div>
                <!--<div class="product-section-search-input">
                    <input type="text" placeholder="Search for Categories">
                </div>-->
                <div class="product-section-check-box">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="checkbox" class="product_cat" name="product_cat" id="<?php echo e($category->name); ?>" value="<?php echo e($category->id); ?>">
                    <label for="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!--<div class="more-product-chekbox-btn">
                    <a href="javascript:void(0)">+ 8 more</a>
                </div>-->
            </div>
            <div class="filter-section-devider"></div>
            <div class="themes-section padding-section responsive-style  filter themes">
                <div class="filter-section-header-text">
                    <h5>THEMES</h5>
                </div>
                <!-- <div class="product-section-search-input">
                    <input type="text" placeholder="Search for Themes">
                </div> -->
                <div class="product-section-check-box">
                    <?php $__currentLoopData = $all_themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="checkbox" class="product_theme" name="product_theme" id="<?php echo e($theme->theme_name); ?>" value="<?php echo e($theme->id); ?>">
                    <label for="<?php echo e($theme->theme_name); ?>"><?php echo e($theme->theme_name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- <div class="more-product-chekbox-btn">
                    <a href="javascript:void(0)">+ 6 more</a>
                </div> -->
            </div>
           <div class="filter-section-devider"></div>

            <div class="gender-section padding-section responsive-style filter gender">
                <div class="filter-section-header-text">
                    <h5>Fitting type</h5>
                </div>
                <div class="product-radio-input-section">
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" id="<?php echo e($type->type_name); ?>" class="fitting_type" name="fitting_type" value="<?php echo e($type->id); ?>">
                    <label for="<?php echo e($type->type_name); ?>"><?php echo e($type->type_name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="filter-section-devider"></div>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="size-section padding-section responsive-style filter size">
                <div class="filter-section-header-text">
                    <h5><?php echo e($option->option_name); ?></h5>
                </div>
                <div class="size-select-btn">
                    <?php $__currentLoopData = $option->option_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label>
                            <input type="checkbox" class="option_value" name="option_value" value="<?php echo e($option_value->id); ?>"><span><?php echo e($option_value->option_value); ?></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="filter-section-devider"></div>
            <div class="gender-section padding-section responsive-style filter gender">
                <div class="filter-section-header-text">
                    <h5>GENDER</h5>
                </div>
                <div class="product-radio-input-section">
                    <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" id="<?php echo e($gender->gender); ?>" class="product_gender" name="product_gender" value="<?php echo e($gender->id); ?>">
                    <label for="<?php echo e($gender->gender); ?>"><?php echo e($gender->gender); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="filter-section-devider"></div>
            <div class="stock-section padding-section responsive-style filter stock">
                <div class="filter-section-header-text">
                    <h5>STOCK</h5>
                </div>
                <div class="product-radio-input-section">
                    <input type="radio" id="in-stock" class="product_stock" name="product_stock" value="1">
                    <label for="in-stock">In Stock</label>
                    <input type="radio" id="out-stock" class="product_stock" name="product_stock" value="0">
                    <label for="out-stock">Out Of Stock</label>
                </div>
            </div>
            <div class="filter-section-devider"></div>
            <div class="price-section padding-section responsive-style filter prices">
                <div class="filter-section-header-text">
                    <h5>PRICES</h5>
                </div>
                <div class="price-input-form">
                    <div class="row g-md-2">
                        <div class="col-md-6 col-6">
                            <div class="product-section-search-input">
                                <input type="number" class="from_price" placeholder="Form">
                            </div>
                        </div>
                        <div class="col-md-6 col-6">
                            <div class="product-section-search-input">
                                <input type="number" class="to_price" placeholder="To">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="responsive-clear-option-btn">
            <div class="clear-all-btn">
                <button>Clear All</button>
            </div>
            <div class="filter-option-btn">
                <button id="hide-filter-option-section" class="close-btn">Close</button>
                <button class="apply-btn">Apply</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/frontend/products-filter.blade.php ENDPATH**/ ?>