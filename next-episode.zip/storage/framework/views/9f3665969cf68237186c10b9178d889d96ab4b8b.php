<script type="text/javascript" src="<?php echo e(asset('frontend/js/jquery-3.4.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend/js/custom.js?v=1')); ?>"></script><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/includes/frontend/footer.blade.php ENDPATH**/ ?>