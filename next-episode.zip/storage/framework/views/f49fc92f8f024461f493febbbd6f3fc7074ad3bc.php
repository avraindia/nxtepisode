<table class="display coustom-table nowrap w-100 Queries">
    <thead>
        <tr>
            <th><a href="javascript:void(0);">Product Name</a></th>
            <th><a href="javascript:void(0);">Default MRP.</a></th>
            <th><a href="javascript:void(0);">Category</a></th>
            <th><a href="javascript:void(0);">Sizes</a></th>
            <th><a href="javascript:void(0);">Variation Price</a></th>
            <th><a href="javascript:void(0);">Current Stock</a></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="table-body-tr">
            <td>
                <span class="pr-title">
                    <?php echo e($inventory->product_title); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($inventory->product_mrp); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($inventory->name); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($inventory->option_value); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($inventory->inventory_price); ?>

                </span>
            </td>
            <td>
                <span class="pr-title">
                    <?php echo e($inventory->current_stock); ?>

                </span>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination-section">
    <?php echo $inventories->links(); ?>

</div><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/admin/inventory-child.blade.php ENDPATH**/ ?>