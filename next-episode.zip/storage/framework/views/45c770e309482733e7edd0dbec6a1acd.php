

<?php $__env->startSection('content'); ?>
<div class="body">
    <div class="title-section clearfix">
        <div class="row">
            <h1>Welcome</h1>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>      

<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>