
<?php $__env->startSection('content'); ?>
<!-- ======================= Border Start Topbar ================== -->
<section class="mt-4">
    <div class="container">
        <div class="row">
            <div class="offset-lg-9 col-lg-3 col-sm-12">
                <a href="<?php echo e(route('add_variation',$product_id)); ?>" class="primary-btn"><i class="bx bxs-plus-circle"></i>Manage Fittings </a>
            </div>
        </div>
    </div>
</section>

<?php if(\Session::has('successmsg')): ?>
<div class="alert alert-success">
    <ul>
        <li><?php echo \Session::get('successmsg'); ?></li>
    </ul>
</div>
<?php endif; ?>

<!-- ======================= Border End Topbar ================== -->
<div class="body">
    <div class="card">
        <div class="card-body">
            <div class="align-items-center d-md-flex justify-content-between mb-4">
                <div class="">
                    <h1 class="card-title m-md-0 mb-3"> Product Inventory</h1>
                </div>
            </div>
            <div class="user_filter">
                <div class="row align-items-center">
                    <div class="col-lg-4">
                        <div class="form-group">
                           <label>Search Keyword</label>
                           <input type="text" name="" class="form-control search_key" value="">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                            <label>Gender</label>
                            <select class="form-control gender_id">
                                <option value="0">All</option>
                                <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gender->id); ?>"><?php echo e($gender->gender); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                            <label>Fitting Type</label>
                            <select class="form-control type_id">
                                <option value="0">All</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="form-group apply-clear-btn">
                            <button type="button" class="btn btn-outline-success apply_filter">Apply</button>
                            <button type="button" class="btn btn-outline-danger clear_filter">Clear</button>
                            <input type="hidden" name="product_id" class="product_id" value="<?php echo e($product_id); ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div id="all-list" class="table-responsive-sm position-relative withdra-tab-content active">
                <?php echo $__env->make('pages.admin.fitting-child', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>

<script>
$('.pagination li [rel=prev]').html('Prev');
$('.pagination li [rel=next]').html('Next');

$(document).on('click', '.page-link', function(e) {
    e.preventDefault();
    var page = $(this).attr('href').split('page=')[1];
    if(page!=""){
        get_filtering_body(page);
    }
});

$(document).on('click', '.apply_filter', function(){
    get_filtering_body(1);
});

$(document).on('click', '.clear_filter', function(){
    location.reload();
});

function get_filtering_body(page){
    var search_key = $('.search_key').val();
    var gender_id = $('.gender_id').val();
    var type_id = $('.type_id').val();
    var product_id = $('.product_id').val();
    var _token = $('meta[name="csrf-token"]').attr('content');

    $.ajax({
        url: "<?php echo e(route('filtering_fitting_paginate_result')); ?>",
        method: 'POST',
        data: {_token: _token, page:page, search_key:search_key, gender_id:gender_id, type_id:type_id, product_id:product_id},
        success: function (data) { 
            $('#all-list').html(data);
            $('.pagination li [rel=prev]').html('Prev');
            $('.pagination li [rel=next]').html('Next');
        }

    }); 
}
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/pages/admin/fitting-list.blade.php ENDPATH**/ ?>