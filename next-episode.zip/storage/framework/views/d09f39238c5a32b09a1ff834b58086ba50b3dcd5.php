<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('includes.frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>
        <div class="main-wrapper">
        <?php echo $__env->make('includes.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
            <section class="footer">
                <?php echo $__env->make('includes.frontend.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
        </div>
        <?php echo $__env->make('includes.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
        
    </body>
</html><?php /**PATH C:\wamp64\www\dev\next-episode\resources\views/layouts/front.blade.php ENDPATH**/ ?>