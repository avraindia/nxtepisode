<?php
echo "Login successfull. This is homepage.";
?>