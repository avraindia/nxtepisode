@extends('layouts.admin')

@section('content')
<div class="body">
    <div class="title-section clearfix">
        <div class="row">
            <h1>Welcome</h1>
        </div>
    </div>

</div>
@stop
@push('scripts')      

@endpush 