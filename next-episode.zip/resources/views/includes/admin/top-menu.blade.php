<header class="topbar">
   <div class="mx-2 ms-auto top-menu-logout-btn">
      <a href="{{route('adminlogout')}}"> Logout <img src="{{ asset('backend/images/icon/log-out.png') }}"></a>
   </div>
   <div class="d-block d-lg-none">
      <div class="toggle">
         <i class='bx bx-menu'></i>
      </div>
   </div>
</header>