<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-4">
        </div>
        <div class="col-lg-3 col-md-6 col-4">
            <div class="footer-ul-header-text">
                <h6>NEED HELP</h6>
            </div>
            <div class="footer-ul">
                <ul>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Track Order</a></li>
                    <li><a href="#">Returns & Refunds</a></li>
                    <li><a href="#">FAQs</a></li>
                    <li><a href="#">My Account</a></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-4">
            <div class="footer-ul-header-text">
                <h6>COMPANY</h6>
            </div>
            <div class="footer-ul">
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Community Initiatives</a></li>
                    <li><a href="#">Souled Armys</a></li>
                </ul>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-4">
            <div class="footer-ul-header-text">
                <h6>MORE INFO</h6>
            </div>
            <div class="footer-ul">
                <ul>
                    <li><a href="#">T&C</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Sitemap</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="copyright-footer-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="copy-right-text">
                    <p>©NEXT EPISODE - All Rights Reserved</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="footer-socil-media-section">
                    <a href="#">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                    <a href="#">
                        <i class="fa-brands fa-instagram"></i>
                    </a>
                    <a href="#">
                        <i class="fa-brands fa-twitter"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>